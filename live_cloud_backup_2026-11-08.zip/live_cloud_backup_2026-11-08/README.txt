Exact copy of the live cloud gist on 2026-11-08.
adhesives_data.json = 51 adhesives + comments + shipments (all fields)
ds_<id>.json = the 10 uploaded datasheet files (PDF data inside)
